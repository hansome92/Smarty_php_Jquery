<?php
    /**
     * File: editor.php
     * Created: 5/28/12  4:02 PM
     * Upgrade, LLC: Upgrade Your Everything
     * www.upgradeyour.com       903-3CODERS
     */
?>
<html>

<head>
    <?php include 'head.php' ?>

    <style type="text/css">
        #openEditorAgain {
            margin-top: 250px;
            background-color: #228aff;
            border: 1px solid gray;
            display: inline-block;
            border-radius: 15px;
            padding: 1px 5px;
        }

    </style>
    <script type="text/javascript">
        var canvas, fabric;
        var isDragDroped;
        var filterName;
        var fontsName;
        var selectItem;
        function applyFilter(index, filter)
        {
            applyFilter(index, filter, null);
        }
        function applyFilter(index, filter, target) {

            var obj = canvas.getActiveObject();
            if (target != null){
                obj = target;
            }
            if (obj == null)
            {
                //   alert('please select image');
            }
            obj.filters[index] = filter;
            obj.applyFilters(canvas.renderAll.bind(canvas));
        }

        function applyFilterValue(index, prop, value) {
            var obj = canvas.getActiveObject();
            if (obj.filters[index]) {
                obj.filters[index][prop] = value;
                obj.applyFilters(canvas.renderAll.bind(canvas));
            }
        }
        var PolaroidPhoto = fabric.util.createClass(fabric.Object, fabric.Observable, {
            H_PADDING: 20,
            V_PADDING: 20,
            initialize: function(src, options) {
                this.callSuper('initialize', options);
                this.image = new Image();
                this.image.src = src;
                this.image.onload = (function() {
                    this.width = this.image.width;
                    this.height = this.image.height;
                    this.loaded = true;
                    this.setCoords();
                    this.fire('image:loaded');
                }).bind(this);
            },
            _render: function(ctx) {
                if (this.loaded) {
                    ctx.fillStyle = '#fff';
                    ctx.fillRect(
                        -(this.width / 2) - this.H_PADDING,
                        -(this.height / 2) - this.H_PADDING,
                        this.width + this.H_PADDING * 2,
                        this.height + this.V_PADDING * 2);
                    ctx.drawImage(this.image, -this.width / 2, -this.height / 2);
                }
            }
        });


        $(document).ready(function () {

            canvas = new fabric.Canvas('editorScrapbookCanvas',{ backgroundImage: 'images/book.png' });
            f = fabric.Image.filters;
            // canvas.add(new fabric.Circle({ radius: 30, fill: '#f55', top: 100, left: 100 }));

            /*  var photo = new PolaroidPhoto('images/sampleTrinkets/butterflyBlue.png', {
              top: 200,
              left: 200,
              scaleX: 0.2,
              scaleY: 0.2
            });
            photo.observe('image:loaded', canvas.renderAll.bind(canvas));
            photo.drawBorders = photo.drawCorners = function() { return this };
            canvas.add(photo);*/

            canvas.observe('object:selected', function (e) {

                canvas.bringToFront(e.target);
            });
            canvas.observe('object:modified', function (e) {
                dropped = e.target;
                droppedLeft = dropped.get('left');
                droppedTop = dropped.get('top');

                droppedWidth = 0 - dropped.getWidth() / 4;
                droppedHeight = 0 - dropped.getHeight() / 4;

                canvasHeight = canvas.getHeight();
                canvasWidth = canvas.getWidth();

                if (droppedLeft > canvasWidth || droppedLeft < droppedWidth || droppedTop > canvasHeight || droppedTop < droppedHeight) {
                    canvas.remove(e.target);
                }

            });

            canvas.observe('object:over', function (e){
                //  e.target.setFill('red');
                //  canvas.renderAll();
                if (isDragDroped){
                    if (selectItem == "images") {
                        removeFilter(e.target);
                        // alert(filterName);
                        if ("preset-gray" == filterName) {

                            applyFilter(0, new f.Grayscale(), e.target);
                        }
                        else if("preset-Invert" == filterName){
                            applyFilter(1,  new f.Invert(), e.target);
                        }
                        else if("preset-Removewhite" == filterName){
                            applyFilter(2, new f.RemoveWhite(60, 10), e.target);
                        }
                        else if("preset-Sepia" == filterName){
                            applyFilter(3,  new f.Sepia(), e.target);
                        }
                        else if("preset-Sepia2" == filterName){
                            applyFilter(4,  new f.Sepia2(), e.target);
                        }
                        else if("preset-brightness" == filterName){
                            applyFilter(5, new f.Brightness({
                                brightness:100}) , e.target);
                        }
                        else if("preset-noise" == filterName){
                            applyFilter(6, new f.Noise({
                                noise:100 }), e.target);
                        }
                        else if("preset-hazyDays" == filterName){
                            applyFilter(7, new f.GradientTransparency({
                                threshold: 20}), e.target
                            );
                        }
                    }

                    filterName = "";
                    isDragDroped = false;

                    // fonts
                    //alert('b' + " " + selectItem);
                    if (selectItem == "fonts") {

                        if ("CA_BND_Web_Bold_700" == fontsName){
                            setFonts(e.target, fontsName);
                        }
                        else if ("DejaVu_Serif_400" == fontsName) {
                            setFonts(e.target, fontsName);
                        }
                        else if ("Delicious_500" == fontsName) {
                            setFonts(e.target, fontsName);
                        }
                        else if ("Encient_German_Gothic_400" == fontsName){
                            setFonts(e.target, fontsName);
                        }
                        else if ("Globus_500" == fontsName) {
                            setFonts(e.target, fontsName);
                        }
                        else if ("OdessaScript_500" == fontsName){
                            setFonts(e.target, fontsName);
                        }
                        else if ("Quake_Cyr" == fontsName) {
                            setFonts(e.target, fontsName);
                        }
                        else if ("Tallys_400" == fontsName) {
                            setFonts(e.target, fontsName);
                        }
                        else if ("Terminator_Cyr" == fontsName) {
                            setFonts(e.target, fontsName);
                        }
                        else if ("Times_New_Roman" == fontsName) {
                            setFonts(e.target, fontsName);
                        }
                        else if ("Vampire95" == fontsName) {
                            setFonts(e.target, fontsName);
                        }

                    }
                    fontsName = "";
                    selectItem = "";
                }
            });



            canvas.findTarget = (function(originalFn) {
                return function() {
                    var target = originalFn.apply(this, arguments);
                    if (target) {
                        if (this._hoveredTarget !== target) {
                            canvas.fire('object:over', { target: target });
                            if (this._hoveredTarget) {
                                canvas.fire('object:out', { target: this._hoveredTarget });
                            }
                            this._hoveredTarget = target;
                        }
                    }
                    else if (this._hoveredTarget) {
                        canvas.fire('object:out', { target: this._hoveredTarget });
                        this._hoveredTarget = null;
                    }
                    if (target == null){
                        isDragDroped = false;
                    }
                    return target;
                };
            })(canvas.findTarget);



            $("#editorVerticalFonts").hide();
            $('#editorVerticalImageFilter').hide();
            $('#editorVerticalPhotos').hide();

            $('#btnAddText').click(function() {

                canvas.add(new fabric.Text($('#txtFonts').val(), {
                    fontFamily: 'CA_BND_Web_Bold_700',
                    left: 300,
                    top: 200
                }));

            });



            $("#menuMiddle").find('li').find('a').click(function(){

                $("#menuMiddle").find('li').each(function(){
                    $(this).find('a').css('color','#898989');
                });


                $(this).css('color', '#68aca8');
                var selmenu = $(this).html().toLowerCase();

                if (selmenu == "wallpapers") {
                    $('#editorVerticalImageFilter').hide();
                    $("#editorVerticalFonts").hide();
                    $('#editorVerticalContentScroller').show();
                    $('#editorVerticalPhotos').hide();
                }
                else if (selmenu == "photo treatments"){
                    $('#editorVerticalImageFilter').show();
                    $('#editorVerticalContentScroller').hide();
                    $("#editorVerticalFonts").hide();
                    $('#editorVerticalPhotos').hide();
                }
                else if (selmenu == "fonts") {
                    $('#editorVerticalImageFilter').hide();
                    $('#editorVerticalContentScroller').hide();
                    $('#editorVerticalPhotos').hide();
                    $("#editorVerticalFonts").show();
                }
                else if (selmenu == "photos") {
                    $('#editorVerticalImageFilter').hide();
                    $('#editorVerticalContentScroller').hide();
                    $('#editorVerticalPhotos').show();
                    $("#editorVerticalFonts").hide();
                }
            });

            $("#first").css('color', '#68aca8');

            $("#yellow").click(function(e){
                var obj = canvas.getActiveObject();
                var px = obj.get("left");
                var py = obj.get("top");

                var width = obj.get("width");
                var height = obj.get("height");

                alert(width);
                //  var scale = obj.get("scale");
                var  p =new  fabric.Line([px - width/2, py, px + width/2, py],{
                    fill:'red',
                    strokeWidth:5
                });
                obj.setBordervisibility = true;
                //  obj.add(p);
                //   obj.add(p);
                canvas.renderAll.bind(canvas);
                //canvas.add(p.s);
            });

        });


        function removeFilter(target)
        {
            var obj = canvas.getActiveObject();
            if (target != null){
                obj = target;
            }

            for (var i = 0; i < 8; i++)
            {
                obj.filters[i] = 0;
            }

            obj.applyFilters(canvas.renderAll.bind(canvas));

        }

        function setFonts(target, fnt) {

            var obj = canvas.getActiveObject();
            if (target != null ) {
                target = obj;
            }

            var px = obj.get('left');
            var py = obj.get('top');
            var text = obj.get('text');
            if (text == "" || text == null){
                return;
            }
            canvas.remove(obj);

            canvas.add(new fabric.Text(text, {
                fontFamily:fnt,
                left: px,
                top: py
            }));
        }

    </script>
</head>
<body>
    <div style="text-align: center;">
        <!-- <div id="openEditorAgain">Open Editor Again</div> -->
    </div>
    <div id="editorHolder">
        <div id="editorInnerHolder">

            <div id="menuHolder">
                <div id="menuTop">
                    <div id="closeEditor" class="btn" title="Close Editor"></div>
                    <div id="saveProgress" class="btn" title="Save Your Changes">Save Progress</div>
                </div>
                <div id="menuBottom">
                    <div>
                        <ul class="lavaLamp" id ="menuMiddle">
                            <li><a id="first">WALLPAPERS</a></li>
                            <li><a >TRINKETS</a></li>
                            <li><a >PHOTO TREATMENTS</a></li>
                            <li><a >FONTS</a></li>
                            <li><a >PHOTOS</a></li>
                        </ul>
                    </div>


                </div>


                <div id="editorMainHolder">

                    <div id="editorScrapbookWindowHolder">
                        <div id="editorScrapbookWindow">
                            <canvas id="editorScrapbookCanvas" width="852" height="632"></canvas>
                        </div>

                        <div id="editorPagination">
                            <img src="images/greenArrowLeft.png" alt="Previous Page" id="goToPreviousPage" class="btn goToPreviousPage">

                            <div id="editorPaginationPrevious" class="btn goToPreviousPage">Previous</div>

                            <div id="editorPaginationPageNumber">
                                <label for="scrapbookPageNumber">Page Number</label>
                                <input type="text" name="scrapbookPageNumber" id="scrapbookPageNumber" value="1">
                            </div>

                            <img src="images/greenArrowRight.png" alt="Next Page" id="goToNextPage" class="btn goToNextPage">

                            <div id="editorPaginationNext" class="btn goToNextPage">Next</div>
                        </div>

                    </div>

                    <div id="editorVerticalContentHolder">

                        <div id="editorVerticalContentScroller">
                            <img src="images/sampleTrinkets/butterflyBlackReal.png" width="200px" alt="trinket" class="trinket">
                            <img src="images/sampleTrinkets/butterflyBlueReal.png" width="200px" alt="trinket" class="trinket">
                            <img src="images/sampleTrinkets/butterflyRedReal.png" width="200px" alt="trinket" class="trinket">
                            <img src="images/sampleTrinkets/butterflyYellowReal.png" width="200px" alt="trinket" class="trinket">
                            <img src="images/sampleTrinkets/butterflyBlue.png" width="200px" alt="trinket" class="trinket">
                            <img src="images/sampleTrinkets/butterflyYellow.png" width="200px" alt="trinket" class="trinket">
                            <img src="images/sampleTrinkets/butterflyPurple.png" width="200px" alt="trinket" class="trinket">
                            <img src="images/sampleTrinkets/butterflyAnimated.gif" width="200px" alt="trinket" class="trinket">
                        </div>

                        <div id="editorVerticalImageFilter">
                            <div id ="preset-gray" class="imageFilter">Grays Scale</div>
                            <div id="preset-Invert" class="imageFilter">Invert</div>
                            <div id="preset-Removewhite" class="imageFilter">Remove white</div>
                            <div id="preset-Sepia" class="imageFilter">Sepia</div>
                            <div id="preset-Sepia2" class="imageFilter">Sepia2</div>
                            <div id="preset-brightness" class="imageFilter">brightness</div>
                            <div id="preset-noise" class="imageFilter">noise</div>
                            <div id="preset-hazyDays" class="imageFilter">hazyDays</div>
                        </div>

                        <div id="editorVerticalFonts">
                            <input type="text" id="txtFonts"/>
                            <br/>
                            <button id="btnAddText" >Add Texts</button>
                            <br/>
                            <div id="CA_BND_Web_Bold_700" class="fonts">CA_BND_Web_Bold</div>
                            <div id="DejaVu_Serif_400" class="fonts">DejaVu_Serif</div>
                            <div id="Delicious_500" class="fonts">Delicious</div>
                            <div id="Encient_German_Gothic_400" class="fonts">Encient_German_Gothic</div>
                            <div id="Globus_500" class="fonts">Globus</div>
                            <div id="OdessaScript_500" class="fonts">OdessaScript</div>
                            <div id="Quake_Cyr" class="fonts">Quake_Cyr</div>
                            <div id="Tallys_400" class="fonts">Tallys</div>
                            <div id="Terminator_Cyr" class="fonts">Terminator_Cyr</div>
                            <div id="Times_New_Roman" class="fonts">Times_New_Roman</div>
                            <div id="Vampire95" class="fonts">Vampire95</div>


                        </div>

                        <div id="editorVerticalPhotos">
                            <!--   <div id="yellow">yellow</div>    -->
                        </div>

                    </div>


                </div>
            </div>

</body>


</html>

