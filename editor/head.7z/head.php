<?php

?>

<!--   YUI stylesheet reset   -->



<!--    jQuery and Plugins    -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" type="text/javascript"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js" type="text/javascript"></script>

<script src="js/jquery.bpopup-0.7.0.min.js" type="text/javascript"></script>

<link href="css/sunny/sunny.css" rel="stylesheet" type="text/css" charset="utf-8">




<!--    feedback    -->
<link href="/planboxFeedback/feedback.css" rel="stylesheet" type="text/css" charset="utf-8">
<script src="/planboxFeedback/feedback.js" type="text/javascript"></script>



<!--    editor   -->
<!--[if IE]><script src="js/excanvas.js" type="text/javascript" ></script><![endif]-->
<script src="js/all.js" type="text/javascript"></script>
<link href="css/editor.css" rel="stylesheet" type="text/css" charset="utf-8">
<link href="css/fonts/felipa.css" rel="stylesheet" type="text/css" charset="utf-8">
<script src="js/editor.js" type="text/javascript"></script>
<script src="js/fonts/CA_BND_Web_Bold_700.font.js" type="text/javascript"></script>
<script src="js/fonts/CrashCTT_400.font.js" type="text/javascript"></script>
<script src="js/fonts/DejaVu_Serif_400.font.js" type="text/javascript"></script>
<script src="js/fonts/Delicious_500.font.js" type="text/javascript"></script>
<script src="js/fonts/Encient_German_Gothic_400.font.js" type="text/javascript"></script>
<script src="js/fonts/Globus_500.font.js" type="text/javascript"></script>
<script src="js/fonts/Modernist_One_400.font.js" type="text/javascript"></script>
<script src="js/fonts/Quake_Cyr.font.js" type="text/javascript"></script>
<script src="js/fonts/Tallys_400.font.js" type="text/javascript"></script>
<script src="js/fonts/Terminator_Cyr.font.js" type="text/javascript"></script>
<script src="js/fonts/Times_New_Roman.font.js" type="text/javascript"></script>
<script src="js/fonts/Vampire95.font.js" type="text/javascript"></script>